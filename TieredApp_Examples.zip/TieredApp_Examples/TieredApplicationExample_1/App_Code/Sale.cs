﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// A class that represent Sale data
/// </summary>
public class Sale
{
    public Sale()
    {
    }

	private string storeID;
    private string orderNumber;
    private DateTime orderDate;
    private short qty;
    private string payTerms;
    private string titleID;


    public string StoreID
    {
        get
        {
            return storeID;

        }
        set
        {
            storeID = value;
        }
    }

    public string Number
    {
        get
        {
            return orderNumber;

        }
        set
        {
            orderNumber = value;
        }
    }

    public DateTime Date
    {
        get
        {
            return orderDate;

        }
        set
        {
            orderDate = value;
        }

    }
    public short Quantity 
    {
        get
        {
            return qty;

        }
        set
        {
            qty = value;
        }

    }
    public string PayTerms
    {
        get
        {
            return payTerms;

        }
        set
        {
            payTerms = value;
        }

    }
    public string TitleID
    {
        get
        {
            return titleID;

        }
        set
        {
            titleID = value;
        }

    }
}