﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// A class that represent Store data
/// </summary>
public class Store
{
    private string storeID;
    private string storeName;
    private string address;
    private string city;
    private string state;
    private string zip;

    
    public string ID
    {
        get 
        {
            return storeID;

        }
        set
        {
            storeID = value;
        }

    }
    public string Name
    {
        get
        {
            return storeName;

        }
        set
        {
            storeName = value;
        }

    }
    public string Address
    {
        get
        {
            return address;

        }
        set
        {
            address= value;
        }

    }
    public string City
    {
        get
        {
            return city;

        }
        set
        {
            city = value;
        }

    }
    public string State
    {
        get
        {
            return state;

        }
        set
        {
            state = value;
        }

    }
    public string Zip
    {
        get
        {
            return zip;

        }
        set
        {
            zip = value;
        }

    }

}