﻿//Represents business layer logic

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


public class StoresBusinessLayer
{
	
	public Store GetStore(string id)
    {
        StoresDataLayer storesDL = new StoresDataLayer();
        return storesDL.GetStore(id);
    }
    
    public List<Store> GetAllStores()
    {
        StoresDataLayer storesDL = new StoresDataLayer();
        return storesDL.GetAllStores();
    }
    
    public void UpdateStore(string newID, string newName, string newAddress, string newCity, string newState, string newZip)
    {
        if (newID.Length != 4) //store ID should be 4 characters long
        {
            throw new ArgumentException("Store ID should be 4 characters");
        }
        
        //this seems acceptable in the DB table definition
        //included it for illustration purposes
        if(String.IsNullOrEmpty(newName))
        {
             throw new ArgumentException("Store name not supplied"); 
        }
       
            Store storeToUpdate = new Store();

            storeToUpdate.ID = newID;
            storeToUpdate.Name = newName;
            storeToUpdate.Address = newAddress;
            storeToUpdate.City = newCity;
            storeToUpdate.State = newState;
            storeToUpdate.Zip = newZip;

            StoresDataLayer storesDL=new StoresDataLayer();
            int result=storesDL.UpdateStore(storeToUpdate);
         
        
        if (result< 1)
             throw new ArgumentException("Error occured during store update"); 
             
    }


    public List<Sale> GetStoreSales(string id)
    {
        StoresDataLayer storesDL = new StoresDataLayer();
        return storesDL.GetStoreSales(id);
    }
}
