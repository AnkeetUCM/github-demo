﻿//Data Access layer class
//Contains methods to retrieve and update store related data

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.ComponentModel;

public class StoresDataLayer
{
    public Store GetStore(string storeID)
    {
        //Retrieves store data based on store ID

        SqlConnection con = new SqlConnection(GetConnectionString());
        string selectSQL = "SELECT * FROM Stores "
            + "WHERE stor_id=@ID";

        SqlCommand cmd = new SqlCommand(selectSQL, con);
        cmd.Parameters.AddWithValue("ID", storeID);

        SqlDataReader reader;

        // Try to open database and read information.
        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            Store store = new Store(); ;
            reader.Read();
            store.ID = reader["stor_id"].ToString();
            store.Name = reader["stor_name"].ToString();
            store.Address = reader["stor_address"].ToString();
            store.City = reader["city"].ToString();
            store.State = reader["state"].ToString();
            store.Zip = reader["zip"].ToString();
            reader.Close();
            con.Close();
           
            return store;

        }

        catch 
        {
            throw new ArgumentException("An error occured during data retrieval");
        }
        finally
        {
            con.Close();
        }
    }

    public List<Store> GetAllStores()
    {
        //A select method that returns a strongly typed collection

        List<Store> allStores = new List<Store>(); //a collection to store query results
        SqlConnection con = new SqlConnection(GetConnectionString());
        string selectSQL = "SELECT * FROM Stores";
        SqlCommand cmd = new SqlCommand(selectSQL, con);
        
        SqlDataReader reader;

        // Try to open database and read information.
        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            Store store;
            while (reader.Read())
            {
                store = new Store(); //an object that represents a store is created for every record retrieved from the DB
                store.ID = reader["stor_id"].ToString();
                store.Name = reader["stor_name"].ToString();
                store.Address = reader["stor_address"].ToString();
                store.City = reader["city"].ToString();
                store.State = reader["state"].ToString();
                store.Zip = reader["zip"].ToString();

                allStores.Add(store);
            }
            reader.Close();
            con.Close();

            return allStores;
        }
        catch 
        {
            throw new ArgumentException("An error occured during data retrieval");
        }
        finally
        {
            con.Close();
        }
    }

   
    public int UpdateStore(Store updated_Store)
    {
        //A method to update the DB

        int updateCount = 0;

        string updateSQL = "UPDATE Stores "
           + " SET stor_name=@Name, "
           + "stor_address=@Address, "
           + "city=@City,"
           + "state=@State,"
           + "zip=@Zip "
           + "WHERE stor_id=@StoreID";

        using (SqlConnection con = new SqlConnection(GetConnectionString()))
        {
            using (SqlCommand cmd = new SqlCommand(updateSQL, con))
            {
                cmd.Parameters.AddWithValue("Name", updated_Store.Name);
                cmd.Parameters.AddWithValue("Address", updated_Store.Address);
                cmd.Parameters.AddWithValue("City", updated_Store.City);
                cmd.Parameters.AddWithValue("State", updated_Store.State);
                cmd.Parameters.AddWithValue("Zip", updated_Store.Zip);
                cmd.Parameters.AddWithValue("StoreID", updated_Store.ID);
                con.Open();
                updateCount = cmd.ExecuteNonQuery();
                con.Close();

            }
        }
        return updateCount;

    }

    public List<Sale> GetStoreSales(string selectedID)
    {
        List<Sale> sales = new List<Sale>();
        SqlConnection con = new SqlConnection(GetConnectionString());
        string selectSQL = "SELECT * FROM sales "
              + "WHERE stor_id=@StoreID"; 

        SqlCommand cmd = new SqlCommand(selectSQL, con);
        
        cmd.Parameters.AddWithValue("StoreID", selectedID);
        SqlDataReader reader;

        // Try to open database and read information.
        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            Sale sale;
            while (reader.Read())
            {
                sale = new Sale();
                sale.StoreID = reader["stor_id"].ToString();
                sale.Number = reader["ord_num"].ToString();
                sale.Date = (DateTime)reader["ord_date"];
                sale.Quantity = (short)reader["qty"];
                sale.PayTerms = reader["payterms"].ToString();
                sale.TitleID = reader["title_id"].ToString();

               sales.Add(sale);
            }
            reader.Close();
            con.Close();
            return sales;
        }
        catch 
        {
            throw new ArgumentException("An error occured during data retrieval");
        }
        finally
        {
            con.Close();
        }
    }


    private static string GetConnectionString()
    {
        return WebConfigurationManager.ConnectionStrings["PubsConnectionString"].ConnectionString;
    }

}