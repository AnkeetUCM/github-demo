﻿//Displays sales of selected store

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Sales : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Populates dropdownlist with stores data
        //Note that this page (presentation layer) uses the business layer class 
        //to get the list of stores

        if (!IsPostBack)
        {
            StoresBusinessLayer storesBL = new StoresBusinessLayer();
            List<Store> stores = storesBL.GetAllStores();

            foreach (Store aStore in stores)
            {
                ListItem newItem = new ListItem();
                newItem.Text = aStore.Name;
                newItem.Value = aStore.ID;
                storesDropDownList.Items.Add(newItem);
            }
        }
    }
    
    protected void storesDropDownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        StoresBusinessLayer storesBL = new StoresBusinessLayer();
        salesGridView.DataSource = storesBL.GetStoreSales(storesDropDownList.SelectedValue.ToString());
        salesGridView.DataBind();
    }
}