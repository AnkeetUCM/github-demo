﻿//Displays the list of stores

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Stores : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Displays data in the gridview using the business layer class

        StoresBusinessLayer storesBL = new StoresBusinessLayer();
        GridView1.DataSource = storesBL.GetAllStores();
        GridView1.DataBind();


        //*** Another approach to display data in gridview*********

        //StoresBusinessLayer storesBL = new StoresBusinessLayer();
        //DataTable newDataTable = new DataTable();
        //newDataTable.Columns.Add("Store ID", typeof(string));
        //newDataTable.Columns.Add("Store Name", typeof(string));
        //newDataTable.Columns.Add("Address", typeof(string));
        //newDataTable.Columns.Add("City", typeof(string));
        //newDataTable.Columns.Add("State", typeof(string));
        //newDataTable.Columns.Add("Zip", typeof(string));

        //Store store = new Store();
        //foreach (Store aStore in storesBL.GetAllStores())
        //{
        //    DataRow newRow = newDataTable.NewRow();
        //    newRow[0] = aStore.ID;
        //    newRow[1] = aStore.Name;
        //    newRow[2] = aStore.Address;
        //    newRow[3] = aStore.City;
        //    newRow[4] = aStore.State;
        //    newRow[5] = aStore.Zip;
        //    newDataTable.Rows.Add(newRow);

        //}

        //GridView1.DataSource = newDataTable;
        //GridView1.DataBind();
    }
   
}