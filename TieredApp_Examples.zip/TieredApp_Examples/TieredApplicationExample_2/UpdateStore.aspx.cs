﻿//Displays a list of stores and allows user to update it
//Could add some validation controls on the page

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UpdateStore : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            StoresBusinessLayer storesBL = new StoresBusinessLayer();
            List<Store> stores = storesBL.GetAllStores();

            foreach (Store aStore in stores)
            {
                ListItem newItem = new ListItem();
                newItem.Text = aStore.Name;
                newItem.Value = aStore.ID;
                storesDropDownList.Items.Add(newItem);
            }
        }
    }


    protected void storesDropDownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        StoresBusinessLayer storesBL = new StoresBusinessLayer();
        Store store=storesBL.GetStore(storesDropDownList.SelectedValue.ToString());
        IDTextBox.Text = store.ID;
        nameTextBox.Text = store.Name;
        addressTextBox.Text = store.Address;
        cityTextBox.Text = store.City;
        stateTextBox.Text = store.State;
        zipTextBox.Text = store.Zip;
    }
    
    protected void updateButton_Click(object sender, EventArgs e)
    {
        try
        {
            StoresBusinessLayer storesBL = new StoresBusinessLayer();
            storesBL.UpdateStore(IDTextBox.Text, nameTextBox.Text, addressTextBox.Text, cityTextBox.Text, stateTextBox.Text, zipTextBox.Text);
        }
        catch (Exception err)
        {
            resultsLabel.Text = err.Message;
        }
    }
}